import SpriteKit
import UIKit

private enum PlayState { case menu, playing, paused, finished }
private enum ItemKind { case petal, seed, obstacleJump, obstacleSlide, shield }

private final class CourseItem {
    let node: SKNode
    let lane: Int
    let kind: ItemKind
    var progress: CGFloat = 0
    var collected = false

    init(node: SKNode, lane: Int, kind: ItemKind) {
        self.node = node
        self.lane = lane
        self.kind = kind
    }
}

final class GardenRunnerScene: SKScene {
    private let worlds = ["春日花园", "彩虹云境", "星光森林", "海边花田", "冬日花谷"]
    private var state: PlayState = .menu
    private var selectedChapter = 1
    private var unlockedChapter: Int { max(1, UserDefaults.standard.integer(forKey: "unlockedChapter")) }

    private let backdrop = SKSpriteNode()
    private let runner = SKSpriteNode()
    private let bunny = SKSpriteNode(imageNamed: "bunny")
    private let titleLabel = SKLabelNode(fontNamed: "PingFangSC-Semibold")
    private let distanceLabel = SKLabelNode(fontNamed: "PingFangSC-Semibold")
    private let petalsLabel = SKLabelNode(fontNamed: "PingFangSC-Semibold")
    private var runnerFrames: [SKTexture] = []
    private var flowMarkers: [SKShapeNode] = []
    private var items: [CourseItem] = []

    private var lane = 1
    private var targetLane = 1
    private var touchOrigin: CGPoint?
    private var touchLane = 1
    private var didVerticalGesture = false
    private var isJumping = false
    private var isSliding = false
    private var hasShield = false
    private var distance: CGFloat = 0
    private var petals = 0
    private var spawnClock: TimeInterval = 3.2
    private var pickupClock: TimeInterval = 0.45
    private var lastUpdate: TimeInterval = 0
    private var sessionStart = Date()
    private var breakShown = false

    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.72, green: 0.91, blue: 1, alpha: 1)
        anchorPoint = .zero
        loadRunnerFrames()
        showMenu()
    }

    override func didChangeSize(_ oldSize: CGSize) {
        guard oldSize != .zero else { return }
        switch state {
        case .menu: showMenu()
        case .playing, .paused: layoutGame()
        case .finished: break
        }
    }

    private func layoutGame() {
        if let texture = backdrop.texture {
            let source = texture.size()
            let scale = max(size.width / source.width, size.height / source.height)
            backdrop.size = CGSize(width: source.width * scale, height: source.height * scale)
            backdrop.position = CGPoint(x: size.width / 2, y: size.height / 2)
        }
        runner.position.x = lanePosition(targetLane, progress: 0.92)
        runner.position.y = size.height * 0.17
        bunny.position = CGPoint(x: runner.position.x - 62, y: runner.position.y - 48)
    }

    private func loadRunnerFrames() {
        runnerFrames = (1...8).map { SKTexture(imageNamed: String(format: "run_%02d", $0)) }
        runnerFrames.forEach { $0.filteringMode = .linear }
    }

    private func configureBackdrop() {
        let texture = SKTexture(imageNamed: "garden_track")
        texture.filteringMode = .linear
        backdrop.texture = texture
        let source = texture.size()
        let scale = max(size.width / source.width, size.height / source.height)
        backdrop.size = CGSize(width: source.width * scale, height: source.height * scale)
        backdrop.position = CGPoint(x: size.width / 2, y: size.height / 2)
        backdrop.zPosition = -100
        addChild(backdrop)
    }

    private func showMenu() {
        removeAllActions()
        removeAllChildren()
        state = .menu
        items.removeAll()
        flowMarkers.removeAll()
        configureBackdrop()

        let veil = SKShapeNode(rectOf: size)
        veil.position = CGPoint(x: size.width / 2, y: size.height / 2)
        veil.fillColor = UIColor(white: 1, alpha: 0.32)
        veil.strokeColor = .clear
        veil.zPosition = -20
        addChild(veil)

        addLabel("云朵花坊跑酷", at: CGPoint(x: size.width / 2, y: size.height * 0.83), size: 34, color: UIColor(red: 0.38, green: 0.25, blue: 0.45, alpha: 1), name: nil)
        addLabel("选择今天的采花旅程", at: CGPoint(x: size.width / 2, y: size.height * 0.78), size: 16, color: UIColor(red: 0.46, green: 0.35, blue: 0.5, alpha: 1), name: nil)

        for chapter in 1...5 {
            let y = size.height * 0.66 - CGFloat(chapter - 1) * 62
            let enabled = chapter <= unlockedChapter
            addButton(
                "\(chapter). \(worlds[chapter - 1])\(enabled ? "" : "  🔒")",
                name: enabled ? "chapter_\(chapter)" : "locked",
                center: CGPoint(x: size.width / 2, y: y),
                width: min(size.width - 54, 340),
                enabled: enabled
            )
        }

        addLabel("单机保存 · 无广告 · 无聊天", at: CGPoint(x: size.width / 2, y: 48), size: 13, color: UIColor(red: 0.39, green: 0.35, blue: 0.45, alpha: 0.8), name: nil)
    }

    private func startChapter(_ chapter: Int) {
        removeAllActions()
        removeAllChildren()
        selectedChapter = chapter
        state = .playing
        lane = 1
        targetLane = 1
        distance = 0
        petals = 0
        spawnClock = 3.8
        pickupClock = 0.35
        lastUpdate = 0
        isJumping = false
        isSliding = false
        hasShield = false
        items.removeAll()
        flowMarkers.removeAll()
        sessionStart = Date()
        breakShown = false

        configureBackdrop()
        createFlowMarkers()
        createHUD()
        createRunner()
    }

    private func createRunner() {
        runner.removeAllActions()
        runner.setScale(1)
        runner.zRotation = 0
        runner.alpha = 1
        runner.texture = runnerFrames.first
        runner.size = CGSize(width: 118, height: 158)
        runner.position = CGPoint(x: lanePosition(1, progress: 0.92), y: size.height * 0.17)
        runner.zPosition = 40
        runner.name = "runner"
        addChild(runner)
        let run = SKAction.animate(with: runnerFrames, timePerFrame: 0.075, resize: false, restore: false)
        runner.run(.repeatForever(run), withKey: "runCycle")

        bunny.removeAllActions()
        bunny.size = CGSize(width: 54, height: 45)
        bunny.position = CGPoint(x: runner.position.x - 62, y: runner.position.y - 48)
        bunny.zPosition = 39
        addChild(bunny)
        bunny.run(.repeatForever(.sequence([
            .moveBy(x: 0, y: 12, duration: 0.18),
            .moveBy(x: 0, y: -12, duration: 0.18)
        ])))
    }

    private func createHUD() {
        let safeTop = view?.safeAreaInsets.top ?? 0
        let top = size.height - max(58, safeTop + 44)
        titleLabel.text = worlds[selectedChapter - 1]
        titleLabel.fontSize = 17
        titleLabel.fontColor = .white
        titleLabel.position = CGPoint(x: size.width / 2, y: top)
        titleLabel.zPosition = 100
        addChild(titleLabel)

        distanceLabel.text = "0 / \(targetDistance) 米"
        distanceLabel.fontSize = 22
        distanceLabel.fontColor = .white
        distanceLabel.position = CGPoint(x: size.width / 2, y: top - 26)
        distanceLabel.zPosition = 100
        addChild(distanceLabel)

        petalsLabel.text = "🌸 0"
        petalsLabel.fontSize = 20
        petalsLabel.fontColor = .white
        petalsLabel.horizontalAlignmentMode = .right
        petalsLabel.position = CGPoint(x: size.width - 22, y: top - 13)
        petalsLabel.zPosition = 100
        addChild(petalsLabel)

        let pause = SKShapeNode(circleOfRadius: 25)
        pause.fillColor = UIColor(white: 1, alpha: 0.76)
        pause.strokeColor = UIColor(white: 1, alpha: 0.5)
        pause.position = CGPoint(x: 37, y: top - 8)
        pause.name = "pause"
        pause.zPosition = 100
        addChild(pause)
        addLabel("Ⅱ", at: .zero, size: 20, color: UIColor(red: 0.38, green: 0.3, blue: 0.48, alpha: 1), name: "pause", parent: pause)

        addLabel("左右滑换道 · 上滑跳跃 · 下滑滑行", at: CGPoint(x: size.width / 2, y: 25), size: 13, color: .white, name: nil)
    }

    private var targetDistance: Int { 650 + selectedChapter * 150 }

    private func createFlowMarkers() {
        for index in 0..<18 {
            let dot = SKShapeNode(ellipseOf: CGSize(width: 5, height: 9))
            dot.fillColor = index % 3 == 0 ? UIColor(red: 1, green: 0.56, blue: 0.7, alpha: 0.8) : UIColor(white: 1, alpha: 0.72)
            dot.strokeColor = .clear
            dot.zPosition = 5
            dot.userData = NSMutableDictionary(dictionary: ["p": CGFloat(index) / 18])
            addChild(dot)
            flowMarkers.append(dot)
        }
    }

    override func update(_ currentTime: TimeInterval) {
        guard state == .playing else { return }
        if lastUpdate == 0 { lastUpdate = currentTime; return }
        let dt = min(0.08, currentTime - lastUpdate)
        lastUpdate = currentTime

        distance += CGFloat(dt) * (27 + CGFloat(selectedChapter) * 2)
        distanceLabel.text = "\(min(targetDistance, Int(distance))) / \(targetDistance) 米"
        animateWorld(dt)
        updateRunner(dt)
        updateItems(dt)
        spawnClock -= dt
        pickupClock -= dt
        if spawnClock <= 0 {
            spawnObstacle()
            spawnClock = max(1.0, 1.75 - Double(selectedChapter) * 0.1) + Double.random(in: 0...0.45)
        }
        if pickupClock <= 0 {
            spawnPickup()
            pickupClock = Double.random(in: 0.42...0.72)
        }

        if distance >= CGFloat(targetDistance) { finishChapter() }
        if !breakShown && Date().timeIntervalSince(sessionStart) >= 20 * 60 {
            breakShown = true
            pauseGame(message: "看看远处，喝口水休息一下吧～")
        }
    }

    private func animateWorld(_ dt: TimeInterval) {
        let pulse = 1 + sin(distance * 0.025) * 0.004
        backdrop.setScale(pulse)
        for (index, marker) in flowMarkers.enumerated() {
            let storedProgress = (marker.userData?["p"] as? NSNumber)?.doubleValue ?? 0
            var p = CGFloat(storedProgress) + CGFloat(dt) * 0.42
            if p > 1 { p -= 1 }
            marker.userData?["p"] = p
            let side: CGFloat = index.isMultiple(of: 2) ? -1 : 1
            marker.position = CGPoint(
                x: size.width / 2 + side * size.width * (0.03 + p * 0.46),
                y: size.height * (0.67 - p * 0.7)
            )
            marker.setScale(0.35 + p * 1.8)
            marker.alpha = 0.2 + p * 0.65
        }
    }

    private func updateRunner(_ dt: TimeInterval) {
        let destination = lanePosition(targetLane, progress: 0.92)
        runner.position.x += (destination - runner.position.x) * min(1, CGFloat(dt) * 22)
        bunny.position.x += ((runner.position.x - 62) - bunny.position.x) * min(1, CGFloat(dt) * 16)
    }

    private func lanePosition(_ lane: Int, progress: CGFloat) -> CGFloat {
        size.width / 2 + CGFloat(lane - 1) * size.width * 0.32 * progress
    }

    private func spawnPickup() {
        let chance = Int.random(in: 0..<12)
        let kind: ItemKind = chance == 0 ? .shield : (chance < 3 ? .seed : .petal)
        let symbol = kind == .shield ? "☁️" : (kind == .seed ? "🌱" : "🌸")
        spawnItem(kind: kind, symbol: symbol, lane: Int.random(in: 0...2))
    }

    private func spawnObstacle() {
        let slide = Bool.random()
        spawnItem(kind: slide ? .obstacleSlide : .obstacleJump, symbol: slide ? "🌿" : "🪨", lane: Int.random(in: 0...2))
    }

    private func spawnItem(kind: ItemKind, symbol: String, lane: Int) {
        let glow = SKShapeNode(circleOfRadius: kind == .petal || kind == .seed || kind == .shield ? 19 : 23)
        glow.fillColor = kind == .obstacleJump || kind == .obstacleSlide ? UIColor(white: 1, alpha: 0.45) : UIColor(red: 1, green: 0.93, blue: 0.72, alpha: 0.75)
        glow.strokeColor = UIColor(white: 1, alpha: 0.6)
        glow.zPosition = 20
        let label = SKLabelNode(text: symbol)
        label.fontSize = kind == .obstacleJump || kind == .obstacleSlide ? 32 : 27
        label.verticalAlignmentMode = .center
        label.position.y = 1
        glow.addChild(label)
        addChild(glow)
        let item = CourseItem(node: glow, lane: lane, kind: kind)
        items.append(item)
    }

    private func updateItems(_ dt: TimeInterval) {
        for item in items where !item.collected {
            item.progress += CGFloat(dt) * (0.22 + CGFloat(selectedChapter) * 0.012)
            let p = item.progress
            item.node.position = CGPoint(x: lanePosition(item.lane, progress: p), y: size.height * (0.68 - p * 0.69))
            item.node.setScale(0.25 + p * 1.15)

            if p > 0.79 && p < 0.98 && item.lane == targetLane {
                switch item.kind {
                case .petal:
                    petals += 1
                    collect(item)
                case .seed:
                    UserDefaults.standard.set(UserDefaults.standard.integer(forKey: "seeds") + 1, forKey: "seeds")
                    collect(item)
                case .shield:
                    hasShield = true
                    collect(item)
                    showToast("云朵护盾准备好啦 ☁️")
                case .obstacleJump:
                    if !isJumping { hitObstacle(item) }
                case .obstacleSlide:
                    if !isSliding { hitObstacle(item) }
                }
            }
        }
        items.removeAll { item in
            if item.collected || item.progress > 1.08 {
                item.node.removeFromParent()
                return true
            }
            return false
        }
    }

    private func collect(_ item: CourseItem) {
        item.collected = true
        petalsLabel.text = "🌸 \(petals)"
        item.node.run(.sequence([.scale(to: 1.7, duration: 0.08), .fadeOut(withDuration: 0.1), .removeFromParent()]))
    }

    private func hitObstacle(_ item: CourseItem) {
        item.collected = true
        if hasShield {
            hasShield = false
            showToast("云朵护盾轻轻接住了你")
            runner.run(.sequence([.fadeAlpha(to: 0.35, duration: 0.08), .fadeAlpha(to: 1, duration: 0.08)]))
        } else {
            finishRun()
        }
    }

    private func jump() {
        guard !isSliding else { return }
        let baseY = size.height * 0.17
        if !isJumping {
            isJumping = true
            runner.removeAction(forKey: "jump")
            runner.run(.sequence([
                .moveTo(y: baseY + 122, duration: 0.24),
                .wait(forDuration: 0.06),
                .moveTo(y: baseY, duration: 0.31),
                .run { [weak self] in self?.isJumping = false }
            ]), withKey: "jump")
        } else if runner.position.y < baseY + 150 {
            runner.removeAction(forKey: "jump")
            runner.run(.sequence([
                .moveTo(y: baseY + 172, duration: 0.18),
                .moveTo(y: baseY, duration: 0.34),
                .run { [weak self] in self?.isJumping = false }
            ]), withKey: "jump")
        }
    }

    private func slide() {
        guard !isJumping, !isSliding else { return }
        isSliding = true
        runner.removeAction(forKey: "slide")
        runner.run(.sequence([
            .group([.scaleX(to: 1.15, duration: 0.1), .scaleY(to: 0.62, duration: 0.1), .rotate(toAngle: -0.13, duration: 0.1)]),
            .wait(forDuration: 0.42),
            .group([.scaleX(to: 1, duration: 0.1), .scaleY(to: 1, duration: 0.1), .rotate(toAngle: 0, duration: 0.1)]),
            .run { [weak self] in self?.isSliding = false }
        ]), withKey: "slide")
    }

    private func finishChapter() {
        state = .finished
        runner.removeAllActions()
        let total = UserDefaults.standard.integer(forKey: "petals") + petals
        UserDefaults.standard.set(total, forKey: "petals")
        if selectedChapter == unlockedChapter && selectedChapter < worlds.count {
            UserDefaults.standard.set(selectedChapter + 1, forKey: "unlockedChapter")
        }
        showResult(title: "花篮装得满满的！", detail: "完成 \(worlds[selectedChapter - 1]) · 带回 🌸\(petals)")
    }

    private func finishRun() {
        guard state == .playing else { return }
        state = .finished
        runner.removeAllActions()
        UserDefaults.standard.set(UserDefaults.standard.integer(forKey: "petals") + petals, forKey: "petals")
        showResult(title: "小心一点哦", detail: "我们整理花篮，再重新出发吧～")
    }

    private func showResult(title: String, detail: String) {
        let card = SKShapeNode(rectOf: CGSize(width: min(size.width - 40, 350), height: 230), cornerRadius: 28)
        card.fillColor = UIColor(white: 1, alpha: 0.94)
        card.strokeColor = UIColor(white: 1, alpha: 0.8)
        card.position = CGPoint(x: size.width / 2, y: size.height / 2)
        card.zPosition = 200
        addChild(card)
        addLabel(title, at: CGPoint(x: 0, y: 58), size: 25, color: UIColor(red: 0.42, green: 0.3, blue: 0.5, alpha: 1), name: nil, parent: card)
        addLabel(detail, at: CGPoint(x: 0, y: 18), size: 14, color: UIColor(red: 0.45, green: 0.39, blue: 0.5, alpha: 1), name: nil, parent: card)
        addButton("重新出发", name: "retry", center: CGPoint(x: 0, y: -42), width: 260, enabled: true, parent: card)
        addLabel("返回花屋", at: CGPoint(x: 0, y: -88), size: 15, color: UIColor(red: 0.45, green: 0.36, blue: 0.5, alpha: 1), name: "home", parent: card)
    }

    private func pauseGame(message: String = "花篮先放一放") {
        guard state == .playing else { return }
        state = .paused
        let overlay = SKShapeNode(rectOf: size)
        overlay.position = CGPoint(x: size.width / 2, y: size.height / 2)
        overlay.fillColor = UIColor(red: 0.18, green: 0.16, blue: 0.28, alpha: 0.5)
        overlay.strokeColor = .clear
        overlay.name = "pauseOverlay"
        overlay.zPosition = 250
        addChild(overlay)
        addLabel(message, at: CGPoint(x: 0, y: 36), size: 20, color: .white, name: nil, parent: overlay)
        addButton("继续跑", name: "resume", center: CGPoint(x: 0, y: -22), width: 230, enabled: true, parent: overlay)
        addLabel("结束本次", at: CGPoint(x: 0, y: -72), size: 15, color: .white, name: "home", parent: overlay)
    }

    private func resumeGame() {
        childNode(withName: "pauseOverlay")?.removeFromParent()
        state = .playing
        lastUpdate = 0
    }

    private func showToast(_ text: String) {
        childNode(withName: "toast")?.removeFromParent()
        let label = addLabel(text, at: CGPoint(x: size.width / 2, y: size.height * 0.29), size: 14, color: .white, name: "toast")
        let plate = SKShapeNode(rectOf: CGSize(width: min(size.width - 50, 310), height: 42), cornerRadius: 21)
        plate.fillColor = UIColor(red: 0.34, green: 0.27, blue: 0.43, alpha: 0.82)
        plate.strokeColor = .clear
        plate.zPosition = 89
        plate.position = label.position
        label.position = .zero
        label.zPosition = 1
        label.removeFromParent()
        plate.name = "toast"
        plate.addChild(label)
        addChild(plate)
        plate.run(.sequence([.wait(forDuration: 1.5), .fadeOut(withDuration: 0.25), .removeFromParent()]))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        touchOrigin = touch.location(in: self)
        touchLane = targetLane
        didVerticalGesture = false
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard state == .playing, let start = touchOrigin, let point = touches.first?.location(in: self) else { return }
        let dx = point.x - start.x
        let dy = point.y - start.y
        if abs(dx) > abs(dy) * 0.82 {
            let laneShift = Int((dx / (size.width * 0.15)).rounded())
            targetLane = max(0, min(2, touchLane + laneShift))
        } else if !didVerticalGesture && abs(dy) > 22 {
            didVerticalGesture = true
            if dy > 0 {
                jump()
            } else {
                slide()
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let point = touches.first?.location(in: self) else { return }
        if state != .playing {
            let names = nodes(at: point).compactMap(\.name)
            if let chapterName = names.first(where: { $0.hasPrefix("chapter_") }), let chapter = Int(chapterName.replacingOccurrences(of: "chapter_", with: "")) {
                startChapter(chapter)
            } else if names.contains("retry") {
                startChapter(selectedChapter)
            } else if names.contains("home") {
                showMenu()
            } else if names.contains("resume") {
                resumeGame()
            }
        } else if nodes(at: point).contains(where: { $0.name == "pause" }) {
            pauseGame()
        } else if let start = touchOrigin, !didVerticalGesture {
            let dx = point.x - start.x
            let dy = point.y - start.y
            if abs(dx) < 18 && abs(dy) < 18 { jump() }
        }
        touchOrigin = nil
    }

    @discardableResult
    private func addLabel(_ text: String, at point: CGPoint, size fontSize: CGFloat, color: UIColor, name: String?, parent: SKNode? = nil) -> SKLabelNode {
        let label = SKLabelNode(fontNamed: "PingFangSC-Semibold")
        label.text = text
        label.fontSize = fontSize
        label.fontColor = color
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.position = point
        label.name = name
        label.zPosition = 100
        (parent ?? self).addChild(label)
        return label
    }

    private func addButton(_ text: String, name: String, center: CGPoint, width: CGFloat, enabled: Bool, parent: SKNode? = nil) {
        let button = SKShapeNode(rectOf: CGSize(width: width, height: 48), cornerRadius: 18)
        button.fillColor = enabled ? UIColor(red: 1, green: 0.63, blue: 0.75, alpha: 0.94) : UIColor(white: 0.88, alpha: 0.82)
        button.strokeColor = UIColor(white: 1, alpha: 0.75)
        button.position = center
        button.name = name
        button.zPosition = 80
        (parent ?? self).addChild(button)
        addLabel(text, at: .zero, size: 17, color: enabled ? .white : UIColor(white: 0.57, alpha: 1), name: name, parent: button)
    }
}
