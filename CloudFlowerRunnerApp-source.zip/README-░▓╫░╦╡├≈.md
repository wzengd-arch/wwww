# 云朵花坊跑酷：Windows 安装到 iPhone 11

这是原生 iPhone 单机游戏，不是网页。游戏数据只保存在手机本地，不需要联网，也没有广告、聊天或内购。

## 第一步：云端生成 IPA

1. 登录 GitHub，新建一个私有仓库。
2. 把本文件夹里的所有内容上传到仓库根目录（需要能直接看到 `project.yml` 和 `.github` 文件夹）。
3. 打开仓库的 **Actions** 页面，选择 **Build unsigned iPhone IPA**。
4. 点 **Run workflow**，等待绿色对勾。
5. 打开完成的任务，在 **Artifacts** 下载 `CloudFlowerRunner-unsigned-ipa`。
6. 解压下载包，得到 `CloudFlowerRunner-unsigned.ipa`。

GitHub 免费账户也可以运行此流程。生成的是未签名 IPA，不需要在 GitHub 填写 Apple 密码或证书。

## 第二步：Windows 侧载到 iPhone

1. Windows 安装 Apple 官方桌面版 iTunes 和 iCloud，以及 Sideloadly。
2. 用数据线连接 iPhone 11，解锁手机并点“信任此电脑”。
3. 打开 Sideloadly，拖入 `CloudFlowerRunner-unsigned.ipa`。
4. 选中自己的 iPhone，输入自己的 Apple ID，在自己电脑上完成签名安装。
5. 手机上若提示未受信任：打开 **设置 → 通用 → VPN 与设备管理**，信任自己的开发者描述文件。
6. 若提示开发者模式：打开 **设置 → 隐私与安全性 → 开发者模式**，按提示重启。

免费 Apple ID 安装的 App 通常 7 天后需要重新签名；再次连接电脑，用 Sideloadly 刷新即可。Apple ID 和密码只在你自己的电脑上输入，不要发送给任何人。

## 操作

- 主角会一直自动向前跑。
- 左右滑：切换三条跑道，拖动过程中即时跟手。
- 上滑：跳跃；空中再上滑一次是二段跳。
- 下滑：滑行穿过低矮花丛。
- 轻点游戏画面：快捷跳跃。
- 收集花瓣、种子和云朵护盾；碰到自然障碍只会温柔结束本次旅程。

## 内容

- 5 个章节：春日花园、彩虹云境、星光森林、海边花田、冬日花谷。
- 8 帧高清跑步动画和兔子伙伴动画。
- 章节逐步解锁，花瓣与种子均保存在手机本地。
- 连续游玩 20 分钟会弹出休息提醒。
